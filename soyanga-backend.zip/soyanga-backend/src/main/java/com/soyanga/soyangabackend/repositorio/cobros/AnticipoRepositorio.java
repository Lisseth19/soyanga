package com.soyanga.soyangabackend.repositorio.cobros;

import com.soyanga.soyangabackend.dominio.Anticipo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnticipoRepositorio extends JpaRepository<Anticipo, Long> {}
