package com.soyanga.soyangabackend.dto.seguridad;

public interface RolListadoProjection {
    Long getIdRol();
    String getNombreRol();
    String getDescripcion();
    Boolean getEstadoActivo();
}
