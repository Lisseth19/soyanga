package com.soyanga.soyangabackend.dto.common;

public record EstadoRequest(Boolean activo) {
}
