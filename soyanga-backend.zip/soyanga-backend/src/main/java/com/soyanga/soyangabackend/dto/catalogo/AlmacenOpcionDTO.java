// AlmacenOpcionDTO.java  (para combos)
package com.soyanga.soyangabackend.dto.catalogo;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AlmacenOpcionDTO {
    private Long id;
    private String nombre;
}
