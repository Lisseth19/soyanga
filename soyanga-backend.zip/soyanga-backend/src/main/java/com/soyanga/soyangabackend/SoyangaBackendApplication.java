package com.soyanga.soyangabackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoyangaBackendApplication {
	public static void main(String[] args) {
		SpringApplication.run(SoyangaBackendApplication.class, args);
	}
}
