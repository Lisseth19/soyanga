package com.soyanga.soyangabackend.dto.cobros;

public interface VentaClienteInfo {
    Long getIdCliente();
}
