package com.soyanga.soyangabackend.repositorio.cobros;

import com.soyanga.soyangabackend.dominio.PagoRecibido;
import com.soyanga.soyangabackend.repositorio.BaseRepository;

public interface PagoRecibidoRepositorio extends BaseRepository<PagoRecibido, Long> {}
