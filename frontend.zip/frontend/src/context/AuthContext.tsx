// src/context/AuthContext.tsx
import React, { createContext, useContext, useEffect, useState } from "react";
import { authService } from "@/servicios/auth"; // o "@/api/auth" según tu árbol
import type { PerfilDTO } from "@/types/auth";

type AuthCtx = {
    user: PerfilDTO | null;
    loading: boolean;
    login: (usuarioOEmail: string, password: string) => Promise<void>;
    logout: () => void;
};

const Ctx = createContext<AuthCtx>({} as any);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<PerfilDTO | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const hasToken = !!localStorage.getItem("accessToken");
        if (!hasToken) {
            setLoading(false);     // ⬅️ importante: no intentes /me sin token
            return;
        }
        (async () => {
            try {
                const me = await authService.me();
                setUser(me);
            } catch {
                // token inválido → limpia sesión
                authService.logout();
                setUser(null);
            } finally {
                setLoading(false);
            }
        })();
    }, []);

    const login = async (usuarioOEmail: string, password: string) => {
        const me = await authService.login(usuarioOEmail, password);
        setUser(me);
    };

    const logout = () => {
        authService.logout();
        setUser(null);
    };

    return (
        <Ctx.Provider value={{ user, loading, login, logout }}>
            {children}
        </Ctx.Provider>
    );
}
