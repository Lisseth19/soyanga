export default function Inicio() {
    return <div className="p-4">Bienvenido a QUE SOYANGA 👋 DENIS EL MANCO</div>
}
